/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The app's scene delegate object.
*/

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

}

