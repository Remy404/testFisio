# Detecting Hand Poses with Vision
Create a virtual drawing app by using Vision's capability to detect hand poses.

## Overview
- Note: This sample code project is associated with WWDC20 session [10653: Detect Body and Hand Pose with Vision](https://developer.apple.com/videos/play/wwdc2020/10653/).


