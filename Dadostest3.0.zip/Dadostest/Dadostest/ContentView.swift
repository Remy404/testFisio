import SwiftUI
import RealityKit
import RealityKitContent

struct ContentView: View {
    
    @State private var showImmersiveSpace = false
    @State private var immersiveSpaceIsShown = false
    @State private var isContentViewVisible = true
    
    @Environment(\.openImmersiveSpace) var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) var dismissImmersiveSpace
    @Environment(\.dismissWindow) var dismissWindow
    @Environment(\.openWindow) var openWindow
    
    var body: some View {
        VStack {
            if isContentViewVisible {
                Button(action: {
                    Task {
                        await openImmersiveSpace(id: "ImmersiveSpace")
                        isContentViewVisible = false
                    }
                }) {
                    Text("start routine")
                        .font(.largeTitle)
                }
            }
        }
        .onChange(of: immersiveSpaceIsShown) { _ in
            isContentViewVisible = true
        }
    }
}

#Preview(windowStyle: .volumetric) {
    ContentView()
}
