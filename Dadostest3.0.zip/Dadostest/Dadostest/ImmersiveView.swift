//
//  ImmersiveView.swift
//  Dadostest
//
//  Created by Alumno on 22/04/24.
//

import SwiftUI
import RealityKit
import RealityKitContent

struct ImmersiveView: View {
    @State private var moveBall = false
    @State private var tapCount = 0
    @Environment(\.dismiss) var dismiss
    
    @State var headEntity: Entity = {
        let headAnchor = AnchorEntity(.head)
        headAnchor.position = [0, 0, 0]
        return headAnchor
    }()
    
    var body: some View {
        ZStack {
            RealityView { content in
                if let ballModel = try? await Entity(named: "scenetest.usda", in: realityKitContentBundle),
                   let ball = ballModel.children.first?.children.first {
                    ball.components[PhysicsMotionComponent.self] = .init()
                    headEntity.addChild(ballModel)
                    content.add(headEntity)
                }
            } update: { content in
                if let scene = content.entities.first {
                    let translation: SIMD3<Float> = moveBall ? [-0.2, 0, 0] : [0, 0, 0]
                    scene.transform.translation += translation
                }
            }
            .gesture(TapGesture()
                .targetedToAnyEntity()
                .onEnded { value in
                    var transform = value.entity.transform
                    transform.translation += SIMD3(-0.3, 0, 0)
                    value.entity.move(
                        to: transform,
                        relativeTo: nil,
                        duration: 1,
                        timingFunction: .easeInOut
                    )
                    
                    // Incrementa el contador de toques
                    tapCount += 1
                    
                    // Verifica si se han hecho 3 toques
                    if tapCount == 3 {
                        Text("pa q no truene, dismissImmersiveView()")
                       dismiss()
                    }
                }
            )
            
            // Muestra el texto con el número de toques
            VStack {
                
                Text("Tocaste la bola \(tapCount) veces")
                    .foregroundColor(.white)
                    .padding()
            }
        }
    }
}



#Preview {
    ImmersiveView()
}
