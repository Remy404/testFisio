//
//  ImmersiveView.swift
//  Dadostest
//
//  Created by Alumno on 22/04/24.
//

import SwiftUI
import RealityKit
import RealityKitContent

struct ImmersiveView: View {
    
    var body: some View {
        RealityView { content in
            
            if let diceModel = try? await Entity(named: "scenetest.usda", in: realityKitContentBundle),
               let dice = diceModel.children.first?.children.first {
                dice.scale = [1, 1, 1]
                print(diceModel)
                
                dice.generateCollisionShapes(recursive: false)
                dice.components.set(InputTargetComponent())
                
                dice.components[PhysicsBodyComponent.self] = .init(PhysicsBodyComponent(
                    massProperties: dice.components[PhysicsBodyComponent.self]!.massProperties,
                    material: .generate(staticFriction: 0.8, dynamicFriction: 0.5, restitution: 0.1),
                    mode: .static
                ))
                dice.components[PhysicsMotionComponent.self] = .init()
                
                content.subscribe(to: CollisionEvents.Began.self, on: dice) { event in
                    print("colision detectada")
                }
                
                content.add(dice)
            }
        }
                .gesture(dragGesture)
        }
            
        var dragGesture: some Gesture {
            DragGesture()
                .targetedToAnyEntity()
                .onChanged{ value in
                    value.entity.position = value.convert(value.location3D, from: .local, to: value.entity.parent!)
                    value.entity.components[PhysicsBodyComponent.self]?.mode = .kinematic
                }
                .onEnded{ value in
                    value.entity.components[PhysicsBodyComponent.self]?.mode = .dynamic
                }
            
                
    }
}


#Preview {
    ImmersiveView()
}
