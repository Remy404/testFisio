//
//  DadostestApp.swift
//  Dadostest
//
//  Created by Alumno on 22/04/24.
//

import SwiftUI

@main
struct DadostestApp: App {
    @State var immsersionStyle:ImmersionStyle = .full
    var body: some Scene {
        WindowGroup {
            ContentView()
        }

        ImmersiveSpace(id: "ImmersiveSpace") {
            ImmersiveView()
        }.immersionStyle(selection: $immsersionStyle, in: .full)
    }
}
