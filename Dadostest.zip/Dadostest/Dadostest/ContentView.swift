//
//  ContentView.swift
//  Dadostest
//
//  Created by Alumno on 22/04/24.
//

import SwiftUI
import RealityKit
import RealityKitContent

struct ContentView: View {
    
    @State private var showImmersiveSpace = false
    @State private var immersiveSpaceIsShown = false
    
    @Environment(\.openImmersiveSpace) var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) var dismissImmersiveSpace
    @Environment(\.dismissWindow) var openWindow
    @Environment(\.openWindow) var dismissWindow
    
    var body: some View {
        
        VStack {
            Button(action: {
                Task{
                    await openImmersiveSpace(id: "ImmersiveSpace")
                    dismissWindow(id: "start")
                }
                
            }){
                Text("start routine")
                    .font(.largeTitle)
            }
            
        }
    }
}

#Preview(windowStyle: .volumetric) {
    ContentView()
}
