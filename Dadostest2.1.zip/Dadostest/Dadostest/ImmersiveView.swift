//
//  ImmersiveView.swift
//  Dadostest
//
//  Created by Alumno on 22/04/24.
//

import SwiftUI
import RealityKit
import RealityKitContent

struct ImmersiveView: View {
    @State private var tapped = false
    
    @State var headEntity: Entity = {
        let headAnchor = AnchorEntity(.head)
        headAnchor.position = [0, 0, 0]
        return headAnchor
    }()
    
    @State var planeEntity: Entity = {
        let tableAnchor = AnchorEntity(.plane(.horizontal, classification: .table, minimumBounds: SIMD2<Float>(0.2,0.2)))
        let planeMesh = MeshResource.generatePlane(width: 0.5, depth: 0.5, cornerRadius: 0.1)
        let material = SimpleMaterial(color: .green, isMetallic: false)
        let planeEntity = ModelEntity(mesh: planeMesh, materials: [material])
        planeEntity.name = "tableplane"
        tableAnchor.addChild(planeEntity)
        return tableAnchor
    }()
    
    var body: some View {
        RealityView { content in
            
            if let ballModel = try? await Entity(named: "scenetest.usda", in: realityKitContentBundle),
               let ball = ballModel.children.first?.children.first {
                
                
                ball.components[PhysicsMotionComponent.self] = .init()
                
                //content.subscribe(to: CollisionEvents.Began.self, on: ball) { event in
                    //print("colision detectada")
                    
                    //}
                
                //content.add(ball)
                headEntity.addChild(ballModel)
                content.add(headEntity)
                }
                
        }
            //.gesture(DragGesture().targetedToAnyEntity())
        .gesture(DragGesture())
            
        }
            
        var dragGesture: some Gesture {
            DragGesture()
                .targetedToAnyEntity()
                .onChanged{ value in
                    value.entity.position = value.convert(value.location3D, from: .local, to: value.entity.parent!)
                    value.entity.components[PhysicsBodyComponent.self]?.mode = .static
                }
                .onEnded{ value in
                    value.entity.components[PhysicsBodyComponent.self]?.mode = .static
                    
                }
            
                
    }
}


#Preview {
    ImmersiveView()
}
